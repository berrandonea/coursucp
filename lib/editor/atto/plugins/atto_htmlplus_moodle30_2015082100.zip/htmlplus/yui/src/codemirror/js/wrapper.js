var _codeMirror = window.codeMirror;
var define = null; // Remove require.js support in this context.
