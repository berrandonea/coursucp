Description of importing the js-beautify library into Moodle.

* git clone https://github.com/einars/js-beautify
* check out the relevant release tag
* copy lib/beautify*.js into lib/yui/src/beautify/js
* copy LICENSE into lib/yui/src/beautify
* update lib/thirdpartylibs.xml
* rebuild the module
