# Changelog

## 2014053003
ed9165d Correct text-alignment for RTL. (Fixes #1)

## 2014053002
2411023 Add plugin maturity

## 2014053001
77ae2bb Wrap CodeMirror content to fit in the current view

## 2014053000
eba2e32 Correct text-alignment for RTL. (fixes #1)

## Older
2636b9d Update version for Moodle 2.7 official relase
65becac Update to version 2014041400 and depend on Moodle 2.7 beta
fd67cae Update to version 2014040800
50950d4 Add a human-readable release
141200b Update plugin name to use the authoratitive name
6f59ede Update to version 2014040700
591ab49 atto_htmlplus: Correct language string file name
d32bc89 Add an initial README file
7cb6c50 atto_htmlplus: Initial commit
