HTML Plus plugin for Atto
=========================

Requirements
============

- Moodle 2.7

Installation
============

* Place in lib/editor/atto/plugins
* Upgrade your Moodle
* Navigate to Site administration -> Plugins -> Text editors -> Atto HTML editor -> Atto toolbar settings
* replace any occurrence of the html plugin with htmlplus
