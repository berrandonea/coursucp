#An Atto plugin to import Word file content cleanly

##Description
The contents of the Word file are converted into clean well-formed HTML and pasted
into the box. 

##Requirements
* The Word files must be in .docx (Word 2007/2010) format.
* The XSL PHP extension must be installed on the Moodle server to enable the Word file conversion.
