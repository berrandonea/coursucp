# format_buttons
"Buttons" is a course format that creates a menu with buttons in javascript to access the sections, one by one. 
It has features to change the button colours and create group of sections.