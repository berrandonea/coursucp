# Enrol by user profile fields plugin for Moodle 2.7-3.0
  
This plugin allows users to be enrolled according to any value stored in their user profile. If you use an external authentication method (LDAP, Shibboleth), you can store values in hidden user fields of the users' Moodle profile, and then use these values to automatically enrol users if some courses.

