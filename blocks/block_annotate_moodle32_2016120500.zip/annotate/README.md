[![Build Status](https://travis-ci.org/annotate-co/moodle-block_annotate.svg?branch=master)](https://travis-ci.org/annotate-co/moodle-block_annotate)

The Annotate block connects Moodle with an Annotate private install. This allows Moodle resources such as PDFs or images to benefit from all the Annotate.co features. For more info on Annotate private installs, visit https://www.annotate.co/private-cloud.html

For more info on plugin features and installation, visit
https://www.annotate.co/moodle.html
