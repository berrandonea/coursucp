<?php

$plugin->version = 2015062000;
$plugin->cron = 0;
$plugin->maturity = MATURITY_STABLE;
$plugin->release = '2.x (Build: 2015062000)';
$plugin->component = 'block_objectives';
$plugin->requires = 2010112400; // Moodle 2.0
