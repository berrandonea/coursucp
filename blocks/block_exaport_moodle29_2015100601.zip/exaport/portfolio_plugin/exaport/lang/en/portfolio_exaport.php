<?php
require substr(__FILE__, 0, strpos(__FILE__, 'exaport')).'/../blocks/exaport/lib/portfolio_plugin'.substr(__FILE__, strpos(__FILE__, 'exaport')+7);
