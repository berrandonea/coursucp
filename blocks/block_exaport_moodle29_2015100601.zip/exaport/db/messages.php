<?php

defined('MOODLE_INTERNAL') || die();

$messageproviders = array (
    'sharing' => array (
    )
);