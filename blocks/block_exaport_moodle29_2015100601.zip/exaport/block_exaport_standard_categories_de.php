<?php 
/* bitte in der Form
	Kategorie 1
	Kategorie 2
	 - Kategorie 2.1
	 - Kategorie 2.2
	Kategorie 3
	 - Kategorie 3.1
	 - Kategorie 3.2
einf�gen */

$string['lang_categories']='
';
?>