#Behat Tests

##Future Tests
* Confirm the correct operation of the groups javascript filter. Ensure that for each choice that the correct group members are selected in the 'from_recipients' box.
* Split the ferpa.feature test into two tests: one for ferpa, one for student usage.
