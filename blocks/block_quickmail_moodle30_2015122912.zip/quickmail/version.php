<?php

// Written at Louisiana State University
//
$plugin->version = 2015122912;
$plugin->requires = 2013051400;
$plugin->release = "v1.5.5";
$plugin->maturity = MATURITY_STABLE; 
$plugin->component = 'block_quickmail';
