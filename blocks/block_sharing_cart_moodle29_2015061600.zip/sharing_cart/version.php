<?php

defined('MOODLE_INTERNAL') || die;

$plugin->version   = 2015061600;
$plugin->requires  = 2012062501.00; // Moodle 2.3.1
$plugin->component = 'block_sharing_cart';
$plugin->release   = '2.9, release 1';
$plugin->maturity  = MATURITY_STABLE;
