To install:
1. Copy the formillalivechat folder to the blocks folder of your Moodle installation.
2. On the Notifications page (Site Administration -> Notifications), you'll find FormillaLiveChat. 
    To install it, click the Upgrade database button.
3. From the Moodle Admin panel, click the "Blocks editing on" button in the top right corner.
4. Click the home page of your Moodle site to configure the Formilla Live Chat block by choosing it from the "Add A Block" dropdown 
    from the bottom left corner of your site.
5. Now configure the block by choosing the settings icon of the Formilla Live Chat block.  Enter your Chat ID after signing up and 
    configure the block on all web pages. 
6. Be sure to click "Blocks editing off" in the top right corner of the Moodle Admin panel when you've completed installation.
