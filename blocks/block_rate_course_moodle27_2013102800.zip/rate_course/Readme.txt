Latest changes
==============

28 Oct 2013
-----------

Moodle 2.5 compliance
Migrated language packs to ATMOS


26 Sept 2012
------------

CONTRIB-3642 - display on site home page
Moodle 2.3 compliance
Added backup and restore support
Better validation on whether questionnaire module is installed and enabled
Improved code documentation and quality

8 July 2013
-----------

Add Block capabilities added
CONTRIB-4415 Non-english Language packs removed