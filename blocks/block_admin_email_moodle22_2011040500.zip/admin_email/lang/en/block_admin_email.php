<?php

// Written at Louisiana State University

$string['pluginname'] = 'Administrative Email';
$string['send_email'] = 'Send Email';
$string['subject'] = 'Subject';
$string['noreply'] = 'No-Reply';
$string['body'] = 'Body';
$string['email_error'] = 'Could not email: {$a->firstname} {$a->lastname} ({$a->email})';
$string['email_error_field'] = 'Can not have an empty: {$a}';
