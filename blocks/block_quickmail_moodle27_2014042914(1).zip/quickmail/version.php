<?php

// Written at Louisiana State University
$plugin->version = 2014042914;
$plugin->requires = 2013051400;
$plugin->release = "v1.5.0";
$plugin->maturity = MATURITY_STABLE; 
