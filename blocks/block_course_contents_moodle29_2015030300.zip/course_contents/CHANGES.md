v3.0
====

* Version numbering scheme changed. No longer this plugin will have separate
  branch for Moodle major version.
* Bug #14 fixed.

v2.6.0
======

* Just a maintenance release tested against Moodle 2.6.2 with no modified
  functionality.

v2.5.0
======

* No real changes, just tested against Moodle 2.5.0.
* Confirmed that the Restrict access section setting is taking into account
  correctly (issue #8).

v2.4.1
======

* Number of sections defined in the course setting is respected (issue #9)
* Block plugin name is used in the Add a block drop down menu

v2.4.0
======

* Moodle 2.4 support
* Added capability "addinstance" (required by Moodle core)
* Rewritten to use the new course formats API
* The section titles enumeration is now configurable (issue #2)
* The block title is now configurable (issue #3)
