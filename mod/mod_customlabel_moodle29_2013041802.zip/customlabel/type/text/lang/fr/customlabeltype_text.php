<?php

$string['text:view'] = 'Peut voir le contenu';
$string['text:addinstance'] = 'Peut ajouter une instance';

$string['pluginname'] = 'Elément de cours : Texte simple';
$string['typename'] = 'Texte simple';
$string['configtypename'] = 'Active le type Texte simple';
$string['textcontent'] = 'Contenu';

$string['template'] = '
<!-- standard default template for unclassed label. Don\'t change -->
<div class="custombox-text">
<%%textcontent%%>
</div>';