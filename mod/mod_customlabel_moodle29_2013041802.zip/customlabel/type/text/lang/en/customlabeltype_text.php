<?php

$string['text:view'] = 'Can view the content';
$string['text:addinstance'] = 'Can add an indstance';

$string['pluginname'] = 'Course element : Simple Text';
$string['typename'] = 'Simple Text';
$string['configtypename'] = 'Enable subtype Simple Text';
$string['textcontent'] = 'Content';

$string['family'] = 'generic';

$string['template'] = '
<!-- standard default template for unclassed label. Don\'t change -->
<div class="custombox-text">
<%%textcontent%%>
</div>';