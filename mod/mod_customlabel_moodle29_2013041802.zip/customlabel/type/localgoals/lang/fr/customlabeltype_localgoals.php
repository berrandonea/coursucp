<?php

$string['localgoals:view'] = 'Peut voir le contenu';
$string['localgoals:addinstance'] = 'Peut ajouter une instance';

$string['pluginname'] = 'Elément de cours : Objectifs';
$string['typename'] = 'Objectifs';
$string['configtypename'] = 'Active le type Objectifs';
$string['localgoals'] = 'Objectifs';

$string['template'] = '
<table class="custombox-localgoals" cellspacing="0" width="100%">
<tr valign="top">
    <td class="custombox-header-thumb localgoals" width="2%" rowspan="2">
    </td>
    <td class="custombox-header-caption localgoals" width="98%">
        Objectifs
    </td>
</tr>
<tr valign="top">
    <td class="custombox-content localgoals">
        <%%localgoals%%>
    </td>
</tr>
</table>';