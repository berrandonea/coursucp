<?php

$string['tipsandtricks:view'] = 'Can view the content';
$string['tipsandtricks:addinstance'] = 'Can add an indstance';

$string['pluginname'] = 'Course element : Tips and Tricks';
$string['typename'] = 'Tips and tricks';
$string['configtypename'] = 'Enable subtype Tips and tricks';
$string['tipsandtricks'] = 'Tips and Tricks';

$string['family'] = 'pedagogic';

$string['template'] = '<table class="custombox-tipsandtricks" cellspacing="0" width="100%">
<tr valign="top">
    <td class="custombox-header-thumb tipsandtricks" width="2%" rowspan="2">
    </td>
    <td class="custombox-header-caption tipsandtricks" width="98%">
        Tips and tricks !
    </td>
</tr>
<tr valign="top">
    <td class="custombox-content tipsandtricks">
        <%%tipsandtricks%%>
    </td>
</tr>
</table>';