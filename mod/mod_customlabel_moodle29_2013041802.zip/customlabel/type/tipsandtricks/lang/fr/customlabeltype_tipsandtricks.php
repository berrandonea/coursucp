<?php

$string['tipsandtricks:view'] = 'Peut voir le contenu';
$string['tipsandtricks:addinstance'] = 'Peut ajouter une instance';

$string['pluginname'] = 'Elément de cours : Trucs et astuces';
$string['typename'] = 'Trucs et astuces';
$string['configtypename'] = 'Active le type Trucs et astuces';
$string['tipsandtricks'] = 'Trucs et astuces';

$string['template'] = '
<table class="custombox-tipsandtricks" cellspacing="0" width="100%">
<tr valign="top">
    <td class="custombox-header-thumb tipsandtricks" width="2%" rowspan="2">
    </td>
    <td class="custombox-header-caption tipsandtricks" width="98%">
        Trucs et astuces !
    </td>
</tr>
<tr valign="top">
    <td class="custombox-content tipsandtricks">
        <%%tipsandtricks%%>
    </td>
</tr>
</table>
';