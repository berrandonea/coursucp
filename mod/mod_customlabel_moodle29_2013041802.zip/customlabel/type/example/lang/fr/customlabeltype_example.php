<?php

$string['example:view'] = 'Peut voir le contenu';
$string['example:addinstance'] = 'Peut ajouter une instance';

$string['pluginname'] = 'Elément de cours : Exemple';
$string['typename'] = 'Exemple';
$string['configtypename'] = 'Active le type Exemple';
$string['example'] = 'Exemple';

$string['template'] = '
<table class="custombox-example" cellspacing="0" width="100%">
<tr valign="top">
    <td class="custombox-header-thumb example" width="2%" rowspan="2">
    </td>
    <td class="custombox-header-caption example" width="98%">
        Exemple...
    </td>
</tr>
<tr>
    <td class="custombox-content example">
        <%%example%%>
    </td>
</tr>
</table>';