<?php

$string['commentbox:view'] = 'Peut voir le contenu';
$string['commentbox:addinstance'] = 'Peut ajouter ue instance';

$string['pluginname'] = 'Elément de cours : Boite de commentaire';
$string['typename'] = 'Boîtes de commentaires';
$string['configtypename'] = 'Active le type Boîtes de commentaires';
$string['comment'] = 'Commentaire ';

$string['template'] = '<div class="custombox-commentbox">
<%%comment%%>
</div>';