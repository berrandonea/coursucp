<?php

$string['commentbox:view'] = 'Can view the content';
$string['commentbox:addinstance'] = 'Can add an instance';

$string['pluginname'] = 'Course element : Comment';
$string['typename'] = 'Comment boxes';
$string['configtypename'] = 'Enable subtype Comment boxes';
$string['comment'] = 'Comment ';

$string['family'] = 'generic';

$string['template'] = '<div class="custombox-commentbox">
<%%comment%%>
</div>';
