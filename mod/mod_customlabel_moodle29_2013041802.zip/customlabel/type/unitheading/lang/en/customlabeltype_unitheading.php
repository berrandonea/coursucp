<?php

$string['unitheading:view'] = 'Can view the content';
$string['unitheading:addinstance'] = 'Can add an indstance';

$string['configtypename'] = 'Enable subtype Unit title';
$string['heading'] = 'Unit title';
$string['imageposition'] = 'Image position';
$string['left'] = 'Left';
$string['none'] = 'No image';
$string['pluginname'] = 'Course element : Unit Heading';
$string['right'] = 'Right';
$string['shortdesc'] = 'Short description';
$string['typename'] = 'Unit title';
$string['imageurl'] = 'Alternate Image URL';
$string['image'] = 'Alternate Image File';
$string['overimagetext'] = 'Text over image';

$string['family'] = 'structure';