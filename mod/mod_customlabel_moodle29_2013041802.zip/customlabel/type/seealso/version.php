<?php

/////////////////////////////////////////////////////////////////////////////////
///  Code fragment to define the version of customlabel
///  This fragment is called by moodle_needs_upgrading() and /admin/index.php
/////////////////////////////////////////////////////////////////////////////////

$plugin = new StdClass();
$plugin->version  = 2015012300;  // The current module version (Date: YYYYMMDDXX)
$plugin->component = 'customlabeltype_seealso';   // Full name of the plugin (used for diagnostics)

