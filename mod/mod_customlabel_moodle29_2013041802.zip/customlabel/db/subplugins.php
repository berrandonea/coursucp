<?php

$subplugins = array('customlabeltype'  => 'mod/customlabel/type');
