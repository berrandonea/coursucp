Never delete files/folders from this directory. 
Not even when you are updating ejsapp.