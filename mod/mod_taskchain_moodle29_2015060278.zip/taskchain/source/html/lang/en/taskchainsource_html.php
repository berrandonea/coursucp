<?php
$string['pluginname'] = 'HTML source files';
