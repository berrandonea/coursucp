<?php
$string['pluginname'] = 'Hot Potatoes source files';
