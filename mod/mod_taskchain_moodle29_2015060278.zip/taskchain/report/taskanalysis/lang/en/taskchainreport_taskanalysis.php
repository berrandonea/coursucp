<?php
$string['pluginname'] = 'Item analysis';
