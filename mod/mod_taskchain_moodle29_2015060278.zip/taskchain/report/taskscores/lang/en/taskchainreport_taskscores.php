<?php
$string['pluginname'] = 'Task scores';
