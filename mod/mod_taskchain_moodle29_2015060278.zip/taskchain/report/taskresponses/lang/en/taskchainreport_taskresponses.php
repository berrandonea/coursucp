<?php
$string['pluginname'] = 'Question responses';
