<?php
$string['pluginname'] = 'Task score';
