<?php
$string['pluginname'] = 'Click trail';
