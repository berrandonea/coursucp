<?php
$string['pluginname'] = 'Chain grade';
