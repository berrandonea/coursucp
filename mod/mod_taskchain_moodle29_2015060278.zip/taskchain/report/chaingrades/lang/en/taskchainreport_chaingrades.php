<?php
$string['pluginname'] = 'Chain grades';
