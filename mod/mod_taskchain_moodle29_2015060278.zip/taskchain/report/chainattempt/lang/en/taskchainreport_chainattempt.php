<?php
$string['pluginname'] = 'Chain attempt';
