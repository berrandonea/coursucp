<?php
$string['pluginname'] = 'Question scores';
