<?php
$string['pluginname'] = 'Hot Potatoes output formats';
