<?php

/**
 * View and administrate BigBlueButton playback recordings
 *
 * @package   mod_bigbluebuttonbn
 * @author    Jesus Federico  (jesus [at] blindsidenetworks [dt] com)
 * @copyright 2012-2014 Blindside Networks Inc.
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v2 or later
 */


/**
 * Custom uninstallation procedure
 */
function xmldb_bigbluebuttonbn_uninstall() {
    return true;
}
