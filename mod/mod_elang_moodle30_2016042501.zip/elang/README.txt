Installation
------------

* Unzip the zip file in the `mod` folder of the moodle directory

* Visit Settings > Site Administration > Notifications and install the E-Lang module

Use
---

See http://e-lang.github.io/moodle-mod_elang/ for conditions of use.
