A drag-and-drop question type

You can use text and / or images as drag items onto defined drop zones on a
background image.

This question type requires that gapselect question type
https://github.com/moodleou/moodle-qtype_gapselect/
to be installed in order to work.

This question type was written by Jamie Pratt (http://jamiep.org/).

This version of this question type is compatible with Moodle 2.5+. There are
other versions available for Moodle 2.3+.

To install using git, type this command in the root of your Moodle install
    git clone git@github.com:moodleou/moodle-qtype_ddimageortext.git question/type/ddimageortext
Then add question/type/ddimageortext to your git ignore.


Alternatively, download the zip from
    https://github.com/moodleou/moodle-qtype_ddimageortext/zipball/master
unzip it into the question/type folder, and then rename the new folder to ddimageortext.
